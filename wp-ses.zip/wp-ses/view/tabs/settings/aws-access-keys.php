<div id="tab-aws-access-keys" data-prefix="wposes" class="wposes-tab wposes-content">
	<?php $this->render_view( 'access-keys' ); ?>
</div>